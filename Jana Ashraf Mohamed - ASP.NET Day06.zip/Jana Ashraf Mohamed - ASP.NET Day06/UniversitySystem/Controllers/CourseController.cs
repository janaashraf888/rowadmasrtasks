﻿using Microsoft.AspNetCore.Mvc;
using UniversitySystem.Models;

namespace UniversitySystem.Controllers
{
    public class CourseController : Controller
    {
        UniversityContext context = new UniversityContext();

        // Get All Courses
        public IActionResult GetAll()
        {
            var courses = context.Courses.ToList();
            return View(courses);
        }

        // Add Course (GET)
        public IActionResult Add()
        {
            return View();
        }

        // Add Course (POST)
        [HttpPost]
        public IActionResult Add(Course course)
        {
            if (ModelState.IsValid)
            {
                context.Courses.Add(course);
                context.SaveChanges();
                return RedirectToAction("GetAll");
            }

            return View(course);
        }

        // Edit Course (GET)
        public IActionResult Edit(int id)
        {
            var course = context.Courses.FirstOrDefault(c => c.Id == id);
            return View(course);
        }

        // Edit Course (POST)
        [HttpPost]
        public IActionResult Edit(Course course)
        {
            if (ModelState.IsValid)
            {
                context.Courses.Update(course);
                context.SaveChanges();
                return RedirectToAction("GetAll");
            }

            return View(course);
        }

        // Delete Course
        public IActionResult Delete(int id)
        {
            var course = context.Courses.FirstOrDefault(c => c.Id == id);

            context.Courses.Remove(course);
            context.SaveChanges();

            return RedirectToAction("GetAll");
        }
    }
}
