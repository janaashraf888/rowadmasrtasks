﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using UniversitySystem.Data;
using UniversitySystem.Models;
using UniversitySystem.ViewModels;
using System.Collections.Generic;

namespace UniversitySystem.Controllers
{
    public class StudentController : Controller
    {
        private readonly AppDbContext context;

        public StudentController(AppDbContext _context)
        {
            context = _context;
        }

        // /Student/ShowAll
        public IActionResult ShowAll()
        {
            var students = context.Students.ToList();
            return View(students);
        }

        // /Student/ShowDetails?id=3
        public IActionResult ShowDetails(int id)
        {
            var student = context.Students.FirstOrDefault(s => s.Id == id);
            return View(student);
        }

        public IActionResult GetAll(string search, int? deptId, int page = 1)
        {
            int pageSize = 5;

            var students = context.Students
                .Include(s => s.Department)
                .AsQueryable();

            if (!string.IsNullOrEmpty(search))
            {
                students = students.Where(s => s.Name.Contains(search));
            }

            if (deptId != null && deptId != 0)
            {
                students = students.Where(s => s.DepartmentId == deptId);
            }

            int totalStudents = students.Count();
            int totalPages = (int)Math.Ceiling((double)totalStudents / pageSize);

            var result = students
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.Departments = context.Departments.ToList();

            return View(result);
        }

        public IActionResult Add()
        {
            ViewBag.deptList = context.Departments.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Add(Student std)
        {
            if (ModelState.IsValid)
            {
                context.Students.Add(std);
                context.SaveChanges();
                return RedirectToAction("GetAll");
            }

            ViewBag.deptList = context.Departments.ToList();
            return View(std);
        }

        public IActionResult Edit(int id)
        {
            var student = context.Students.Find(id);
            ViewBag.Departments = context.Departments.ToList();
            return View(student);
        }

        [HttpPost]
        public IActionResult Edit(Student std)
        {
            if (ModelState.IsValid)
            {
                context.Students.Update(std);
                context.SaveChanges();
                return RedirectToAction("GetAll");
            }

            ViewBag.deptList = context.Departments.ToList();
            return View(std);
        }

        public IActionResult Delete(int id)
        {
            var student = context.Students.Find(id);
            return View(student);
        }

        [HttpPost]
        public IActionResult ConfirmDelete(int id)
        {
            var student = context.Students.Find(id);
            context.Students.Remove(student);
            context.SaveChanges();
            return RedirectToAction("GetAll");
        }

        // ------------------- NEW ACTION: StudentCourseResult -------------------
        // Displays the student, course, degree, and color (green/red) without conditions in the view
        public IActionResult StudentCourseResult(int studentId, int courseId)
        {
            var student = context.Students.FirstOrDefault(s => s.Id == studentId);
            var course = context.Courses.FirstOrDefault(c => c.Id == courseId);

            // Use the correct DbSet name: StuCrsResults
            var studentCourse = context.StuCrsResults
                .FirstOrDefault(sc => sc.StudentId == studentId && sc.CourseId == courseId);

            if (student == null || course == null || studentCourse == null)
            {
                return NotFound();
            }

            StudentCourseDegreeVM vm = new StudentCourseDegreeVM
            {
                StudentName = student.Name,
                CourseName = course.Name,
                Degree = studentCourse.Degree, // make sure StuCrsRes has Degree property
                Color = studentCourse.Degree >= course.MinDegree ? "green" : "red"
            };

            return View(vm);
        }
        // ------------------------------------------------------------------------
    }
}