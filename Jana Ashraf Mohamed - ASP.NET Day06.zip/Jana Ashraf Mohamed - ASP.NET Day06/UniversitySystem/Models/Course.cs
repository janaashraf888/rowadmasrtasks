﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace UniversitySystem.Models
{
    public class Course
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Course name is required")]
        [MinLength(3, ErrorMessage = "Course name must be at least 3 characters")]
        public string Name { get; set; }

        [Range(0, 100, ErrorMessage = "Degree must be between 0 and 100")]
        public int Degree { get; set; }

        [Range(0, 100, ErrorMessage = "Minimum degree must be between 0 and 100")]
        public int MinDegree { get; set; }

        [Required(ErrorMessage = "Department is required")]
        public int DepartmentId { get; set; }

        public Department Department { get; set; }

        public List<Teacher> Teachers { get; set; }

        public List<StuCrsRes> StuCrsResults { get; set; }
    }
}