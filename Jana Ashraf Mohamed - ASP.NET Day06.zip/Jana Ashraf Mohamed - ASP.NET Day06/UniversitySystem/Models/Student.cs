﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using UniversitySystem.Models;

public class Student
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Student name is required")]
    [MinLength(3, ErrorMessage = "Name must be at least 3 characters")]
    [MaxLength(50, ErrorMessage = "Name cannot exceed 50 characters")]
    public string Name { get; set; }

    [Range(18, 60, ErrorMessage = "Age must be between 18 and 60")]
    public int Age { get; set; }

    [Required(ErrorMessage = "Department must be selected")]
    public int DepartmentId { get; set; }

    public Department Department { get; set; }

    public List<StuCrsRes> StuCrsResults { get; set; }
}