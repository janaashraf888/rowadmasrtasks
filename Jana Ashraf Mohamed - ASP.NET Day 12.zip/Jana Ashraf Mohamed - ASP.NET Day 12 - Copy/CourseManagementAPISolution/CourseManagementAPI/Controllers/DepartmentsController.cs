using CourseManagementAPI.Data;
using CourseManagementAPI.DTOs;
using CourseManagementAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace CourseManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public DepartmentsController(AppDbContext context)
        {
            _context = context;
        }

        // Way 1: Using DTO
        [HttpGet("WithCountDTO")]
        public async Task<ActionResult<IEnumerable<DepartmentCourseCountDto>>> GetDepartmentsWithCountDTO()
        {
            var departments = await _context.Departments
                .Include(d => d.Courses)
                .Select(d => new DepartmentCourseCountDto
                {
                    DeptName = d.Name,
                    CoursesCount = d.Courses.Count
                })
                .ToListAsync();

            return Ok(departments);
        }

        // Way 2: Customize serialization options (using Anonymous Objects and JsonResult)
        [HttpGet("WithCountCustom")]
        public async Task<IActionResult> GetDepartmentsWithCountCustom()
        {
            var departments = await _context.Departments
                .Include(d => d.Courses)
                .Select(d => new
                {
                    d.Name,
                    CourseCount = d.Courses.Count
                })
                .ToListAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            };

            return new JsonResult(departments, options);
        }
    }
}
