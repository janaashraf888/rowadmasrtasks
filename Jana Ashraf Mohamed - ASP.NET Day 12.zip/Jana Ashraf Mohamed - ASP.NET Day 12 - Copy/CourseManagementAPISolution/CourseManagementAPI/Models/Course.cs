using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CourseManagementAPI.Models
{
    public class Course
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [Column("Crs_name")]
        [MaxLength(50)]
        public string? Crs_name { get; set; }

        [Column("crs_desc")]
        [MaxLength(150)]
        public string? crs_desc { get; set; }

        public int? Duration { get; set; }

        public int? DeptID { get; set; }
        [ForeignKey("DeptID")]
        public virtual Department? Department { get; set; }
    }
}
