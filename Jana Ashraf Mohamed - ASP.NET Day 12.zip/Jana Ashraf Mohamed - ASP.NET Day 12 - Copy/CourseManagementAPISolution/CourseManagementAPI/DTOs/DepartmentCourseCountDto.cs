namespace CourseManagementAPI.DTOs
{
    public class DepartmentCourseCountDto
    {
        public string DeptName { get; set; }
        public int CoursesCount { get; set; }
    }
}
