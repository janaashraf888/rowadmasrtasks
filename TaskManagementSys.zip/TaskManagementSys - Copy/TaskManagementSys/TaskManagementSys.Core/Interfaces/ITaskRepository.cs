using TaskManagementSys.Core.Entities;

namespace TaskManagementSys.Core.Interfaces
{
    public interface ITaskRepository
    {
        Task<IEnumerable<TaskItem>> GetAllAsync();
        Task<IEnumerable<TaskItem>> GetAllAsync(bool? isCompleted);
        Task<IEnumerable<TaskItem>> GetAllAsync(bool? isCompleted, bool sortByDueDate);
        Task<TaskItem?> GetByIdAsync(int id);
        Task<TaskItem> CreateAsync(TaskItem task);
        Task<TaskItem> UpdateAsync(TaskItem task);
        Task DeleteAsync(int id);
    }
}
