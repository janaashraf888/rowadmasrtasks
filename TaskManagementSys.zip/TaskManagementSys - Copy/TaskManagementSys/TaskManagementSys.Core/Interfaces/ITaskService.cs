using TaskManagementSys.Core.Entities;

namespace TaskManagementSys.Core.Interfaces
{
    public interface ITaskService
    {
        Task<IEnumerable<TaskItem>> GetAllTasksAsync();
        Task<IEnumerable<TaskItem>> GetAllTasksAsync(bool? isCompleted);
        Task<IEnumerable<TaskItem>> GetAllTasksAsync(bool? isCompleted, bool sortByDueDate);
        Task<TaskItem?> GetTaskByIdAsync(int id);
        Task<TaskItem> CreateTaskAsync(TaskItem task);
        Task<TaskItem> UpdateTaskAsync(TaskItem task);
        Task DeleteTaskAsync(int id);
    }
}
