using TaskManagementSys.Core.Entities;
using TaskManagementSys.Core.Interfaces;

namespace TaskManagementSys.Service.Services
{
    public class TaskService : ITaskService
    {
        private readonly ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        public async Task<IEnumerable<TaskItem>> GetAllTasksAsync()
        {
            return await _taskRepository.GetAllAsync();
        }

        public async Task<IEnumerable<TaskItem>> GetAllTasksAsync(bool? isCompleted)
        {
            return await _taskRepository.GetAllAsync(isCompleted);
        }

        public async Task<IEnumerable<TaskItem>> GetAllTasksAsync(bool? isCompleted, bool sortByDueDate)
        {
            return await _taskRepository.GetAllAsync(isCompleted, sortByDueDate);
        }

        public async Task<TaskItem?> GetTaskByIdAsync(int id)
        {
            return await _taskRepository.GetByIdAsync(id);
        }

        public async Task<TaskItem> CreateTaskAsync(TaskItem task)
        {
            ValidateTask(task);
            return await _taskRepository.CreateAsync(task);
        }

        public async Task<TaskItem> UpdateTaskAsync(TaskItem task)
        {
            ValidateTask(task);
            return await _taskRepository.UpdateAsync(task);
        }

        public async Task DeleteTaskAsync(int id)
        {
            await _taskRepository.DeleteAsync(id);
        }

        private void ValidateTask(TaskItem task)
        {
            if (string.IsNullOrWhiteSpace(task.Title))
            {
                throw new ArgumentException("Title is required.");
            }

            if (task.Title.Length > 100)
            {
                throw new ArgumentException("Title cannot exceed 100 characters.");
            }

            if (task.Description != null && task.Description.Length > 500)
            {
                throw new ArgumentException("Description cannot exceed 500 characters.");
            }

            if (task.DueDate.HasValue && task.DueDate.Value < DateTime.UtcNow)
            {
                throw new ArgumentException("DueDate must be in the future.");
            }
        }
    }
}
