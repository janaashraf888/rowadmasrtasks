# Task Management System Web API

A clean architecture-based Task Management System built with .NET 9, Entity Framework Core, and SQL Server.

## Architecture

The solution follows a clean architecture pattern with four layers:

- **TaskManagementSys.Core**: Contains entities, interfaces, and domain logic
- **TaskManagementSys.Infrastructure**: Contains data access, DbContext, and repository implementations
- **TaskManagementSys.Service**: Contains business logic and service implementations
- **TaskManagementSys.API**: Contains controllers, API endpoints, and application configuration

## Features

- **CRUD Operations**: Create, Read, Update, and Delete tasks
- **Filtering**: Filter tasks by completion status (IsCompleted)
- **Sorting**: Sort tasks by due date
- **Validation**: Business logic validation including:
  - Title is required (max 100 characters)
  - Description max 500 characters
  - DueDate must be in the future

## TaskItem Entity

- **Id**: Primary key
- **Title**: Required, max 100 characters
- **Description**: Optional, max 500 characters
- **IsCompleted**: Boolean, defaults to false
- **CreatedAt**: DateTime, defaults to current UTC date
- **DueDate**: Optional DateTime

## API Endpoints

### Get All Tasks
```
GET /api/tasks
Query Parameters:
- isCompleted (optional): Filter by completion status (true/false)
- sortByDueDate (optional): Sort by due date (true/false)
```

### Get Task by ID
```
GET /api/tasks/{id}
```

### Create Task
```
POST /api/tasks
Body: TaskItem JSON
```

### Update Task
```
PUT /api/tasks/{id}
Body: TaskItem JSON
```

### Delete Task
```
DELETE /api/tasks/{id}
```

## Database Configuration

The application uses SQL Server LocalDB with the following connection string in `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=TaskManagementDb;Trusted_Connection=True;MultipleActiveResultSets=true"
  }
}
```

## Running the Application

1. Restore dependencies:
```bash
dotnet restore
```

2. Build the solution:
```bash
dotnet build
```

3. Run the API:
```bash
dotnet run --project TaskManagementSys.API
```

The API will be available at `https://localhost:5001` or `http://localhost:5000`.

## Database Migrations

To create a new migration:
```bash
dotnet ef migrations add MigrationName --project TaskManagementSys.Infrastructure --startup-project TaskManagementSys.API
```

To update the database:
```bash
dotnet ef database update --project TaskManagementSys.Infrastructure --startup-project TaskManagementSys.API
```

## Technologies Used

- .NET 9
- Entity Framework Core 9.0
- SQL Server (LocalDB)
- ASP.NET Core Web API
- Repository Pattern
- Dependency Injection
