﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementSystem.Core.Entities;
using System.Linq;

namespace TaskManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly ITaskService _service;

        public TasksController(ITaskService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var tasks = _service.GetAll();
            return Ok(tasks);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var task = _service.GetById(id);

            if (task == null)
                return NotFound();

            return Ok(task);
        }

        [HttpGet("filter")]
        public IActionResult GetByStatus(bool isCompleted)
        {
            var tasks = _service.GetAll()
                                 .Where(t => t.IsCompleted == isCompleted);

            return Ok(tasks);
        }

        [HttpGet("sorted")]
        public IActionResult GetSortedByDueDate()
        {
            var tasks = _service.GetAll()
                                 .OrderBy(t => t.DueDate)
                                 .ToList();

            return Ok(tasks);
        }

        [HttpPost]
        public IActionResult Create(TaskItem task)
        {
            _service.Create(task);
            return Ok(task);
        }

        [HttpPut]
        public IActionResult Update(TaskItem task)
        {
            _service.Update(task);
            return Ok(task);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.Delete(id);
            return Ok();
        }
    }
}