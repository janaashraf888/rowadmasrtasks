﻿using TaskManagementSystem.Core.Entities;
using TaskManagementSystem.Core.Interfaces;
namespace TaskManagementSystem.Core.Services
{
    public class TaskService : ITaskService
    {
        private readonly ITaskRepository _repository;

        public TaskService(ITaskRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<TaskItem> GetAll()
        {
            return _repository.GetAll();
        }

        public TaskItem GetById(int id)
        {
            return _repository.GetById(id);
        }

        public void Create(TaskItem task)
        {
            task.CreatedAt = DateTime.Now;
            _repository.Add(task);
            _repository.Save();
        }

        public void Update(TaskItem task)
        {
            _repository.Update(task);
            _repository.Save();
        }

        public void Delete(int id)
        {
            _repository.Delete(id);
            _repository.Save();
        }
    }
}