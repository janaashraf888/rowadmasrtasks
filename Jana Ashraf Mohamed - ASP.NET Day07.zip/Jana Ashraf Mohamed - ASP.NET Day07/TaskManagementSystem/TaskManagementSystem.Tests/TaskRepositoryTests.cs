﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementSystem.Core.Entities;
using TaskManagementSystem.Infrastructure.Data;
using TaskManagementSystem.Infrastructure.Repositories;
using Xunit;

namespace TaskManagementSystem.Tests
{
    public class TaskRepositoryTests
    {
        private AppDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new AppDbContext(options);
        }
        [Fact]
        public void Add_Task_Should_Save_To_Database()
        {
            // Arrange (prepare data)
            var context = GetDbContext();
            var repo = new TaskRepository(context);

            var task = new TaskItem
            {
                Title = "Test Task",
                Description = "Test Description",
                IsCompleted = false,
                CreatedAt = DateTime.Now
            };

            // Act (perform action)
            repo.Add(task);
            repo.Save();

            // Assert (check result)
            var result = context.Tasks.FirstOrDefault();

            Assert.NotNull(result);
            Assert.Equal("Test Task", result.Title);
        }
        [Fact]
        public void GetAll_Should_Return_Tasks()
        {
            var context = GetDbContext();
            var repo = new TaskRepository(context);

            context.Tasks.Add(new TaskItem { Title = "Task 1" });
            context.Tasks.Add(new TaskItem { Title = "Task 2" });
            context.SaveChanges();

            var result = repo.GetAll();

            Assert.Equal(2, result.Count());
        }
        [Fact]
        public void Delete_Task_Should_Remove_It()
        {
            var context = GetDbContext();
            var repo = new TaskRepository(context);

            var task = new TaskItem { Title = "To Delete" };
            context.Tasks.Add(task);
            context.SaveChanges();

            repo.Delete(task.Id);
            repo.Save();

            var result = context.Tasks.FirstOrDefault();

            Assert.Null(result);
        }
        [Fact]
        public void Add_Task_ShouldIncreaseCount()
        {
            var context = GetDbContext();
            var repo = new TaskRepository(context);

            repo.Add(new TaskItem
            {
                Title = "Test Task",
                Description = "Test",
                IsCompleted = false
            });

            repo.Save();

            Assert.Equal(1, context.Tasks.Count());
        }
    }
}
