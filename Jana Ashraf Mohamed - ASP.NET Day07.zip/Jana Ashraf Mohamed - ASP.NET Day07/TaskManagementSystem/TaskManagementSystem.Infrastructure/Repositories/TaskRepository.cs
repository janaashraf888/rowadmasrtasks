﻿using System;
using System.Collections.Generic;
using System.Linq;
using TaskManagementSystem.Core.Entities;
using TaskManagementSystem.Core.Interfaces;
using TaskManagementSystem.Infrastructure.Data;

namespace TaskManagementSystem.Infrastructure.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        private readonly AppDbContext _context;

        public TaskRepository(AppDbContext context)
        {
            _context = context;
        }

        // GET ALL
        public IEnumerable<TaskItem> GetAll()
        {
            return _context.Tasks.ToList();
        }

        // GET BY ID
        public TaskItem GetById(int id)
        {
            return _context.Tasks.Find(id);
        }

        // ADD
        public void Add(TaskItem task)
        {
            _context.Tasks.Add(task);
        }

        // UPDATE
        public void Update(TaskItem task)
        {
            _context.Tasks.Update(task);
        }

        // DELETE
        public void Delete(int id)
        {
            var task = _context.Tasks.Find(id);
            if (task != null)
            {
                _context.Tasks.Remove(task);
            }
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public IEnumerable<TaskItem> GetByStatus(bool isCompleted)
        {
            return _context.Tasks
                .Where(t => t.IsCompleted == isCompleted)
                .ToList();
        }

        public IEnumerable<TaskItem> GetSortedByDueDate()
        {
            return _context.Tasks
                .OrderBy(t => t.DueDate)
                .ToList();
        }

    }

    }