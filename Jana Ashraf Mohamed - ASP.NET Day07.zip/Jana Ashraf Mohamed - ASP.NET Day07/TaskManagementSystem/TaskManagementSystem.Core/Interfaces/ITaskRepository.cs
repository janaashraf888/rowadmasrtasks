﻿using TaskManagementSystem.Core.Entities;

namespace TaskManagementSystem.Core.Interfaces
{
    public interface ITaskRepository
    {
        IEnumerable<TaskItem> GetAll();

        TaskItem GetById(int id);

        void Add(TaskItem task);

        void Update(TaskItem task);

        void Delete(int id);

        void Save();
        IEnumerable<TaskItem> GetByStatus(bool isCompleted);

        IEnumerable<TaskItem> GetSortedByDueDate();
    }
}