﻿using TaskManagementSystem.Core.Entities;

public interface ITaskService
{
    IEnumerable<TaskItem> GetAll();
    TaskItem GetById(int id);
    void Create(TaskItem task);
    void Update(TaskItem task);
    void Delete(int id);
}