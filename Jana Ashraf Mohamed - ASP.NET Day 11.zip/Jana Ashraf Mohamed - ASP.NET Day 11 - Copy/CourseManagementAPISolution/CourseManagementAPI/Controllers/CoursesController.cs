using CourseManagementAPI.Data;
using CourseManagementAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CourseManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CoursesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CoursesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Courses
        [HttpGet]
        public IActionResult get()
        {
            var courses = _context.Courses.ToList();
            if (courses.Count == 0)
            {
                return NotFound();
            }
            return Ok(courses);
        }

        // GET: api/Courses/5
        [HttpGet("{id}")]
        public IActionResult getById(int id)
        {
            var course = _context.Courses.Find(id);
            if (course == null)
            {
                return NotFound();
            }
            return Ok(course);
        }

        // GET: api/Courses/byname/{name}
        [HttpGet("byname/{name}")]
        public IActionResult couseByName(string name)
        {
            var course = _context.Courses.FirstOrDefault(c => c.Crs_name == name);
            if (course == null)
            {
                return NotFound();
            }
            return Ok(course);
        }

        // POST: api/Courses
        [HttpPost]
        public IActionResult post([FromBody] Course course)
        {
            if (course == null)
            {
                return BadRequest();
            }

            _context.Courses.Add(course);
            _context.SaveChanges();

            return CreatedAtAction(nameof(getById), new { id = course.ID }, course);
        }

        // PUT: api/Courses/5
        [HttpPut("{id}")]
        public IActionResult put(int id, [FromBody] Course course)
        {
            if (id != course.ID)
            {
                return BadRequest();
            }

            var existingCourse = _context.Courses.Find(id);
            if (existingCourse == null)
            {
                return NotFound();
            }

            existingCourse.Crs_name = course.Crs_name;
            existingCourse.crs_desc = course.crs_desc;
            existingCourse.Duration = course.Duration;

            _context.SaveChanges();

            return NoContent();
        }

        // DELETE: api/Courses/5
        [HttpDelete("{id}")]
        public IActionResult deleteCourse(int id)
        {
            var course = _context.Courses.Find(id);
            if (course == null)
            {
                return NotFound();
            }

            _context.Courses.Remove(course);
            _context.SaveChanges();

            var courses = _context.Courses.ToList();
            return Ok(courses);
        }
    }
}
