using CourseManagementAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CourseManagementAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Course> Courses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Course>(entity =>
            {
                entity.ToTable("Courses");
                entity.Property(e => e.ID).ValueGeneratedOnAdd();
                entity.Property(e => e.Crs_name).HasMaxLength(50).IsRequired(false);
                entity.Property(e => e.crs_desc).HasMaxLength(150).IsRequired(false);
                entity.Property(e => e.Duration).IsRequired(false);
            });
        }
    }
}
