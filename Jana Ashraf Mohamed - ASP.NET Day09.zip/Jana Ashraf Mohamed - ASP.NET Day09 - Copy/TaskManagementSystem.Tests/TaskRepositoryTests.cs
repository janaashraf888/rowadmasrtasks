using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.Core.Entities;
using TaskManagementSystem.Infrastructure.Data;
using TaskManagementSystem.Infrastructure.Repositories;

namespace TaskManagementSystem.Tests
{
    public class TaskRepositoryTests
    {
        private TaskDbContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<TaskDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            var context = new TaskDbContext(options);
            return context;
        }

        [Fact]
        public async Task GetAllAsync_ReturnsAllTasks()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new TaskRepository(context);

            context.TaskItems.AddRange(
                new TaskItem { Title = "Task 1", Description = "Description 1", IsCompleted = false },
                new TaskItem { Title = "Task 2", Description = "Description 2", IsCompleted = true }
            );
            await context.SaveChangesAsync();

            // Act
            var result = await repository.GetAllAsync();

            // Assert
            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task GetAllAsync_WithFilter_ReturnsFilteredTasks()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new TaskRepository(context);

            context.TaskItems.AddRange(
                new TaskItem { Title = "Task 1", Description = "Description 1", IsCompleted = false },
                new TaskItem { Title = "Task 2", Description = "Description 2", IsCompleted = true },
                new TaskItem { Title = "Task 3", Description = "Description 3", IsCompleted = false }
            );
            await context.SaveChangesAsync();

            // Act
            var result = await repository.GetAllAsync(false);

            // Assert
            Assert.Equal(2, result.Count());
            Assert.All(result, t => Assert.False(t.IsCompleted));
        }

        [Fact]
        public async Task GetByIdAsync_ReturnsTask()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new TaskRepository(context);

            var task = new TaskItem { Title = "Task 1", Description = "Description 1", IsCompleted = false };
            context.TaskItems.Add(task);
            await context.SaveChangesAsync();

            // Act
            var result = await repository.GetByIdAsync(task.Id);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Task 1", result.Title);
        }

        [Fact]
        public async Task GetByIdAsync_ReturnsNullWhenNotFound()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new TaskRepository(context);

            // Act
            var result = await repository.GetByIdAsync(999);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task AddAsync_AddsTask()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new TaskRepository(context);

            var task = new TaskItem { Title = "New Task", Description = "New Description", IsCompleted = false };

            // Act
            var result = await repository.AddAsync(task);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Id > 0);
            Assert.Equal("New Task", result.Title);
        }

        [Fact]
        public async Task UpdateAsync_UpdatesTask()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new TaskRepository(context);

            var task = new TaskItem { Title = "Original Title", Description = "Original Description", IsCompleted = false };
            context.TaskItems.Add(task);
            await context.SaveChangesAsync();

            // Act
            task.Title = "Updated Title";
            task.IsCompleted = true;
            var result = await repository.UpdateAsync(task);

            // Assert
            Assert.Equal("Updated Title", result.Title);
            Assert.True(result.IsCompleted);
        }

        [Fact]
        public async Task DeleteAsync_DeletesTask()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new TaskRepository(context);

            var task = new TaskItem { Title = "Task to Delete", Description = "Description", IsCompleted = false };
            context.TaskItems.Add(task);
            await context.SaveChangesAsync();

            // Act
            await repository.DeleteAsync(task.Id);
            var result = await repository.GetByIdAsync(task.Id);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAllAsync_SortsByDueDate()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new TaskRepository(context);

            var task1 = new TaskItem { Title = "Task 1", Description = "Description 1", IsCompleted = false, DueDate = new DateTime(2024, 1, 15) };
            var task2 = new TaskItem { Title = "Task 2", Description = "Description 2", IsCompleted = false, DueDate = new DateTime(2024, 1, 10) };
            var task3 = new TaskItem { Title = "Task 3", Description = "Description 3", IsCompleted = false, DueDate = new DateTime(2024, 1, 20) };

            context.TaskItems.AddRange(task1, task2, task3);
            await context.SaveChangesAsync();

            // Act
            var result = await repository.GetAllAsync();
            var resultList = result.ToList();

            // Assert
            Assert.Equal(3, resultList.Count);
            Assert.Equal("Task 2", resultList[0].Title);
            Assert.Equal("Task 1", resultList[1].Title);
            Assert.Equal("Task 3", resultList[2].Title);
        }
    }
}
