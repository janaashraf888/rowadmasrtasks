using TaskManagementSystem.Core.Entities;

namespace TaskManagementSystem.Service.Interfaces
{
    public interface ITaskService
    {
        Task<IEnumerable<TaskItem>> GetAllTasksAsync(bool? isCompleted = null);
        Task<TaskItem?> GetTaskByIdAsync(int id);
        Task<TaskItem> CreateTaskAsync(TaskItem taskItem);
        Task<TaskItem> UpdateTaskAsync(TaskItem taskItem);
        Task DeleteTaskAsync(int id);
    }
}
