using TaskManagementSystem.Core.Entities;
using TaskManagementSystem.Core.Interfaces;
using TaskManagementSystem.Service.Interfaces;

namespace TaskManagementSystem.Service.Services
{
    public class TaskService : ITaskService
    {
        private readonly ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        public async Task<IEnumerable<TaskItem>> GetAllTasksAsync(bool? isCompleted = null)
        {
            return await _taskRepository.GetAllAsync(isCompleted);
        }

        public async Task<TaskItem?> GetTaskByIdAsync(int id)
        {
            return await _taskRepository.GetByIdAsync(id);
        }

        public async Task<TaskItem> CreateTaskAsync(TaskItem taskItem)
        {
            if (string.IsNullOrWhiteSpace(taskItem.Title))
            {
                throw new ArgumentException("Task title is required.");
            }

            if (taskItem.Title.Length > 100)
            {
                throw new ArgumentException("Task title cannot exceed 100 characters.");
            }

            if (taskItem.Description != null && taskItem.Description.Length > 500)
            {
                throw new ArgumentException("Task description cannot exceed 500 characters.");
            }

            return await _taskRepository.AddAsync(taskItem);
        }

        public async Task<TaskItem> UpdateTaskAsync(TaskItem taskItem)
        {
            if (string.IsNullOrWhiteSpace(taskItem.Title))
            {
                throw new ArgumentException("Task title is required.");
            }

            if (taskItem.Title.Length > 100)
            {
                throw new ArgumentException("Task title cannot exceed 100 characters.");
            }

            if (taskItem.Description != null && taskItem.Description.Length > 500)
            {
                throw new ArgumentException("Task description cannot exceed 500 characters.");
            }

            var existingTask = await _taskRepository.GetByIdAsync(taskItem.Id);
            if (existingTask == null)
            {
                throw new KeyNotFoundException($"Task with ID {taskItem.Id} not found.");
            }

            return await _taskRepository.UpdateAsync(taskItem);
        }

        public async Task DeleteTaskAsync(int id)
        {
            var existingTask = await _taskRepository.GetByIdAsync(id);
            if (existingTask == null)
            {
                throw new KeyNotFoundException($"Task with ID {id} not found.");
            }

            await _taskRepository.DeleteAsync(id);
        }
    }
}
