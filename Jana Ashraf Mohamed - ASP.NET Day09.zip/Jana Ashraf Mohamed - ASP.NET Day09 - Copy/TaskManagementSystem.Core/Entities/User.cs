using System.ComponentModel.DataAnnotations;

namespace TaskManagementSystem.Core.Entities
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Username { get; set; } = string.Empty;

        [Required]
        [MaxLength(256)]
        public string Password { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? Email { get; set; }
    }
}
