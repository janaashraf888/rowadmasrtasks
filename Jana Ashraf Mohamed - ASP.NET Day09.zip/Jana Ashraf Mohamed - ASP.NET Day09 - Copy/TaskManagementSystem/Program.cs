using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.Core.Interfaces;
using TaskManagementSystem.Infrastructure.Data;
using TaskManagementSystem.Infrastructure.Repositories;
using TaskManagementSystem.Service.Interfaces;
using TaskManagementSystem.Service.Services;

namespace TaskManagementSystem
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            // Configure DbContext
            builder.Services.AddDbContext<TaskDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            // Add Cookie Authentication
            builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    options.Cookie.HttpOnly = true;
                    options.ExpireTimeSpan = TimeSpan.FromHours(1);
                    options.LoginPath = "/login";
                    options.AccessDeniedPath = "/login";
                    options.SlidingExpiration = true;
                });

            // Register Repository
            builder.Services.AddScoped<ITaskRepository, TaskRepository>();

            // Register Service
            builder.Services.AddScoped<ITaskService, TaskService>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            // Custom route for Task list with optional filter
            app.MapControllerRoute(
                name: "taskList",
                pattern: "task/{status?}",
                defaults: new { controller = "Task", action = "Index" });

            // Custom route for Task CRUD operations
            app.MapControllerRoute(
                name: "taskDetails",
                pattern: "task/details/{id}",
                defaults: new { controller = "Task", action = "Details" });

            app.MapControllerRoute(
                name: "taskCreate",
                pattern: "task/create",
                defaults: new { controller = "Task", action = "Create" });

            app.MapControllerRoute(
                name: "taskEdit",
                pattern: "task/edit/{id}",
                defaults: new { controller = "Task", action = "Edit" });

            app.MapControllerRoute(
                name: "taskDelete",
                pattern: "task/delete/{id}",
                defaults: new { controller = "Task", action = "Delete" });

            // Default route for other controllers
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
